<?php
@session_start();
include "inc/koneksi.php";
if (@$_SESSION['admin']|| @$_SESSION['member']) {
?>

<!DOCTYPE html>
<html>
<head>
	<title>Politeknik Negeri Medan</title>
	<link rel="stylesheet" href="css/main.css">

</head>

<body background="img/bg.jpg">

<div id="canvas">
	<div id="header">
	<img src="img/logopolmed.png" />
	</div>

	<div id="menu">
		<ul>
			<li class="akademik"><a href="?page=beranda">Beranda</a></li>
			<li class="akademik"><a href="">Tugas Akademik</a>
				<ul>
					<li><a href="?page=mahasiswa&nipdosen=<?php echo $data['nip']; ?>">Mahasiswa</a></li>
					<li><a href="?page=dosen">Dosen</a></li>
					<li><a href="?page=matakuliah">Mata Kuliah</a></li>
					<li><a href="?page=kuliah&kode_mk=<?php echo $data['kodemk']; ?>">Kuliah</a></li>
					<li><a href="?page=peserta&kode_kuliah=<?php echo $data['kodekuliah'];?>">Peserta</a></li>
					
				</ul></li>
			<li class="akademik"><a href="?page=profil">Profil</a></li>
			<li class="akademik" style="float:right; background-color:#000000;"><a href="logout.php">Logout</a></li>
			<li class="akademik"><a href="?page=bukutamu&user_name<? echo $data['username']; ?>">Buku Tamu</a></li>
			<li class="utama" style="float:right;">
			<?php
				if(@$_SESSION['admin']) {
					$user_terlogin = $_SESSION['admin'];
				} else if(@$_SESSION['member']) {
					$user_terlogin = $_SESSION['member'];
				}

			$sql_user = mysql_query("select * from user where username= '$user_terlogin'") or die (mysql_error());
			$data_user = mysql_fetch_array($sql_user);
			?>
			<a>Selamat datang, <?php echo $data_user['nama_lengkap'];?></a></li>
		</ul>
	</div>

	<div id="isi">
		
		<?php
		$page = @$_GET['page'];
		$action = @$_GET['action'];

			if ($page =="profil") {
			include "profil/profil.php";
		} 

		if($page == "dosen") {
			if ($action =="") {
			include "akademik/dosen.php";
			} elseif ($action == "editdosen") {
				include "akademik/editdosen.php";
			} elseif ($action == "hapusdosen") {
				include "akademik/hapusdosen.php";
			}
		 }

		if ($page == "mahasiswa") {
			if ($action == "") {
				include "akademik/mahasiswa.php";
			} elseif ($action == "editmahasiswa") {
				include "akademik/editmahasiswa.php";
			} elseif ($action == "hapusmahasiswa") {
				include "akademik/hapusmahasiswa.php";
			}
		}

		if($page == "matakuliah") {
			if($action == "") {
			include "akademik/matakuliah.php";
			} elseif ($action == "editmatakuliah") {
				include "akademik/editmatakuliah.php";
			} elseif ($action == "hapusmatakuliah") {
				include "akademik/hapusmatakuliah.php";
			} 
		 }

		if($page == "kuliah") {
			if($action == "") {
			include "akademik/kuliah.php";
			} elseif ($action == "editkuliah") {
				include "akademik/editkuliah.php";
			} elseif ($action == "hapuskuliah") {
				include "akademik/hapuskuliah.php";
			}
		} if($page == "beranda"){
			include "beranda/beranda.php";
			} elseif ($page == "") {
			include "beranda/beranda.php";
			
		}

		if($page == "peserta") {
			if ($action =="") {
			include "akademik/peserta.php";
			} elseif ($action == "editpeserta") {
				include "akademik/editpeserta.php";
			} elseif ($action == "hapuspeserta") {
				include "akademik/hapuspeserta.php";
			} elseif ($page == "") {
				include "beranda/beranda.php";
			} else {
				echo "failed";
			}
		}
		if ($page == "bukutamu") {
			include "buku_tamu/bukutamu.php";
		} 

	?>

	</div>

	<div id="footer">

	Copyright © 2015 - MUHAMMAD BOBBY SYAHDAN LUBIS - All Rights Reserved

	</div>
</div>
</body>
</html>

<?php
} else {
	header("location:login.php");
}
?>