<?php
$kode_kuliah = @$_GET['kode_kuliah'];

mysql_query("delete from kuliah where kodekuliah='$kode_kuliah'") or die(mysql_error());
?>

<script type="text/javascript">
	window.location.href = "?page=kuliah";
</script>
