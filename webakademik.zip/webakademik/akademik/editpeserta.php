<fieldset>
	<legend>Update Data Peserta</legend>

	<form method="post" action="">
	<table>

		<tr>
			<td>Kode Kuliah</td>
			<td>:</td>
			<td><select name="kodekuliah">
		
		<?php
		$kode_kuliah = @$_GET['kode_kuliah'];
		$sql = mysql_query("select * from kuliah") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[0]</option>";
		}
	?>
				?>
			</select></td>
		</tr>
		<tr>
			<td>Nim</td>
			<td>:</td>
			<td><select name="nim">

				<?php
		$nimmahasiswa = @$_GET['nimmahasiswa'];
		$sql = mysql_query("select * from mahasiswa") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>
			</select></td>
		</tr>
		<tr>


	<?php
	$kode_kuliah = @$_GET['kode_kuliah'];
	$sql = mysql_query("select * from peserta where kodekuliah = '$kode_kuliah'") or die (mysql_error());
	$data = mysql_fetch_array($sql);

	?>
			<td>Nilai</td>
			<td>:</td>
			<td><input type="text" name="nilai" value="<?php echo $data['nilai']; ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit" name="update" value="Update"> <input type="reset" name="reset" value="Batal"></td>
		</tr>
	</table>
</form>
</fieldset>

<?php
$kodekuliah = @$_POST['kodekuliah'];
$nim = @$_POST['nim'];
$nilai = @$_POST['nilai'];
$update = @$_POST['update'];

if($update) {
	if ($nilai == "") {
		?>
		<script type="text/javascript">
			alert("Inputan Masih ada yang kosong.");
		</script>
		<?php
	} else {
		mysql_query("update peserta set kodekuliah = '$kode_kuliah',nim = '$nim', nilai = '$nilai' where kodekuliah = '$kode_kuliah' && nim='$nimmahasiswa'") or die (mysql_error());
	}
	?>
	<script type="text/javascript">
		alert("Data peserta berhasil diupdate.");
		window.location.href="?page=peserta";
	</script>
	<?php
}
?>
