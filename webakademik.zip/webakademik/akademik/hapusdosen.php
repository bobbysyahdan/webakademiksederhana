<?php
$nipdosen = @$_GET['nipdosen'];

mysql_query("delete from dosen where nip='$nipdosen'");
?>

<script type="text/javascript">
	window.location.href = "?page=dosen";
</script>
