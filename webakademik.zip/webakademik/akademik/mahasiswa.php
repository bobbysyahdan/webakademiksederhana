<fieldset>
	<legend>Menambah Data Mahasiswa</legend>

<table>
	

<form method="post" action="">
<tr>
	<td>NIM</td>
	<td>:</td>
	<td><input type="text" name="nim"></td>
</tr>

<tr>
	<td>Nama</td>
	<td>:</td>
	<td><input type="text" name="nama"></td>
</tr>

<tr>
	<td>Dosen Pembimbing</td>
	<td>:</td>
	<td><select name="nip">
		<?php
		$nipdosen = @$_GET['nipdosen'];
		$sql = mysql_query("select * from dosen") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>
	</select></td>
</tr>

<tr>
	<td></td>
	<td></td>
	<td><input type="submit" name="tambah" value="Tambah"><input type="reset" name="reset" value="Batal"></td>
</tr>
</form>
</table>

<?php

	$nim = @$_POST['nim'];
	$nama = @$_POST['nama'];
	$nip = @$_POST['nip'];
	$tambah = @$_POST['tambah'];


	if ($tambah) {
		if($nim == "" || $nama == "" || $nip == "") {
		?>
		<script type=text/javascript>
			alert("Inputan masih ada yang kosong");
		</script>

		<?php
	} else {
		mysql_query("insert into mahasiswa values('$nim','$nama','$nip')") or die (mysql_error());
	}
	
	?>
	<script type="text/javascript">
	alert("Data mahasiswa berhasil ditambah");
	window.location.href="?page=mahasiswa" ;
	</script>
	<?php
	}

?>
</fieldset>

<br>
<br>
<h3 align="center">Data Mahasiswa</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>
		<th>NIM</th>
		<th>Nama</th>
		<th>Dosen Pembimbing</th>
		<th>Opsi</th>
	</tr>

	<tr>
		<?php
		$sql = mysql_query("select * from mahasiswa") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?>
			<tr>
				<th><?php echo $data['nim']; ?></th>
				<th><?php echo $data['nama']; ?></th>
				<th><?php echo $data['dosenpembimbing']; ?></th>
				<th><a href="?page=mahasiswa&action=editmahasiswa&nimmahasiswa=<?php echo $data['nim']; ?>"><button>Edit</button></a>
				<a onclick = "return confirm('Apakah anda yakin akan menghapus data ini ?')" href=?page=mahasiswa&action=hapusmahasiswa&nimmahasiswa=<?php echo $data['nim']; ?>><button>Hapus</button></a></th>
			</tr>


		<?php
			}
		?>
	</tr>
</table>
