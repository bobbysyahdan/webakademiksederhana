<?php
$kode_mk = $_GET['kode_mk'];
mysql_query("delete from matakuliah where kodemk = '$kode_mk'");
?>

<script type="text/javascript">
	window.location.href="?page=matakuliah";
</script>