<fieldset>
	<legend>Update Data Dosen</legend>

	<?php
	$nipdosen = @$_GET['nipdosen'];
	$sql = mysql_query("select * from dosen where nip='$nipdosen'") or die (mysql_error());
	$data = mysql_fetch_array($sql);
	?>

<table>
<form method="post" action="">
	<tr>
		<td>NIP</td>
		<td>:</td>
		<td><input type="text" name="nip" value="<?php echo $data['nip']; ?>" disabled="disable"></td>
	</tr>
	<tr>
	<td>Nama</td>
		<td>:</td>
		<td><input type="text" name="nama" value="<?php echo $data['nama']; ?>"></td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td><input type="submit" name="update" value="Update"><input type="reset" name="reset" value="Batal"></td>
	</tr>
</form>
</table>

<?php
	$nip = @$_POST['nip'];
	$nama = @$_POST['nama'];
	$update = @$_POST['update'];


	if ($update) {
		if($nama == "") {
		?>
		<script type=text/javascript>
			alert("Inputan masih ada yang kosong");
		</script>

		<?php
	} else {
		mysql_query("update dosen set nama='$nama' where nip = '$nipdosen'") or die (mysql_error());
	}
	
	?>
	<script type="text/javascript">
	alert("Data dosen berhasil diupdate");
	window.location.href="?page=dosen" ;
	</script>
	<?php
	}

?>
</fieldset>