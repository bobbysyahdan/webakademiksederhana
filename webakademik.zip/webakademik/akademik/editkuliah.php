<fieldset>
	<legend>Edit Data Kuliah</legend>

<?php
	$kode_kuliah = @$_GET['kode_kuliah'];
	$sql = mysql_query("select * from kuliah where kodekuliah='$kode_kuliah'") or die(mysql_error());
	$data = mysql_fetch_array($sql);
?>
<form method="post" action="">
<table>
	<tr>
		<td>Kode Kuliah</td>
		<td>:</td>
		<td><input type="text" name="kodekuliah" value="<?php echo $data['kodekuliah']; ?>" disabled="disable"></td>
	</tr>
	<tr>
		<td>Kodemk</td>
		<td>:</td>
		<td><select name="kodemk">
		<?php
		$kode_mk = @$_GET['kode_mk'];
		$sql = mysql_query("select * from matakuliah") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>

		</select></td>
	</tr>
	<tr>
		<td>Nip</td>
		<td>:</td>
		<td><select name="nip">
		
		<?php
		$nipdosen = @$_GET['nipdosen'];
		$sql = mysql_query("select * from dosen") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>
		</select></td>
	</tr>


<?php
	$kode_kuliah = @$_GET['kode_kuliah'];
	$sql = mysql_query("select * from kuliah where kodekuliah='$kode_kuliah'") or die(mysql_error());
	$data = mysql_fetch_array($sql);
?>
	<tr>
		<td>Tahun Akademik</td>
		<td>:</td>
		<td><input type="text" name="thnakademik" value="<?php echo $data['thnakademik']; ?>" ></td>
	</tr>
	<tr>
		<td>Ruang</td>
		<td>:</td>
		<td><input type="text" name="ruang" value="<?php echo $data['ruang']; ?>"></td>
	</tr>
	<tr>
		<td>Jam</td>
		<td>:</td>
		<td><input type="text" name="jam" value="<?php echo $data['jam']; ?>"></td>
	</tr>
	<tr>
		<td>Semester</td>
		<td>:</td>
		<td><input type="text" name="semester" value="<?php echo $data['semester']; ?>"></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td><input type="submit" name="update" value="Update"><input type="reset" name="reset" value="Batal"></td>
	</tr>
	</table>
	</form>
</fieldset>

<?php
$kodekuliah = @$_POST['kodekuliah'];
$kodemk = @$_POST['kodemk'];
$nip = @$_POST['nip'];
$thnakademik = @$_POST['thnakademik'];
$ruang = @$_POST['ruang'];
$jam = @$_POST['jam'];
$semester = @$_POST['semester'];
$update = @$_POST['update'];


if ($update) {
	if ($kodemk == "" || $nip == "" || $thnakademik == "" || $ruang == "" || $jam == "" || $semester == "") {
		?>
		<script type="text/javascript">
			alert("Inputan masih ada yang kosong.")
		</script>
		<?php
	} else {
		mysql_query("update kuliah set kodemk='$kodemk', nip='$nip', thnakademik='$thnakademik', ruang='$ruang', jam='$jam', semester='$semester' where kodekuliah='$kode_kuliah'") or die (mysql_query());
	}
	?>
	<script type="text/javascript">
		alert("Data kuliah berhasil diupdate");
		window.location.href ="?page=kuliah";
	</script>
	<?php
}
?>
