<fieldset>
	<legend>Tambah Data Peserta</legend>

	<form method="post" action="">
	<table>
		<tr>
			<td>Kode Kuliah</td>
			<td>:</td>
			<td><select name="kodekuliah">
		
		<?php
		$kode_kuliah = @$_GET['kode_kuliah'];
		$sql = mysql_query("select * from kuliah") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[0]</option>";
		}
	?>
				?>
			</select></td>
		</tr>
		<tr>
			<td>Nim</td>
			<td>:</td>
			<td><select name="nim">

				<?php
		$nimmahasiswa = @$_GET['nimmahasiswa'];
		$sql = mysql_query("select * from mahasiswa") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>
			</select></td>
		</tr>
		<tr>
			<td>Nilai</td>
			<td>:</td>
			<td><input type="text" name="nilai"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit" name="tambah" value="Tambah"><input type="reset" name="reset" value="Batal"></td>
		</tr>
	</table>
</form>
</fieldset>


<?php
$kodekuliah = @$_POST['kodekuliah'];
$nim = @$_POST['nim'];
$nilai = @$_POST['nilai'];
$tambah = @$_POST['tambah'];

if ($tambah) {
	if ($kodekuliah == "" || $nim == "" || $nilai == ""){
		?>
		<script type="text/javascript">
			alert("Inputan masih ada yang kosong.");
		</script>
		<?php
	} else {
		mysql_query("insert into peserta values('$kodekuliah','$nim','$nilai')") or die (mysql_error());
	?>
	<script type="text/javascript">
		alert("Data peserta berhasil ditambah.");
		window.location.href="?page=peserta";
	</script>
	<?php
	}
	}
?>

<br>
<h3 align="center">Data Peserta</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>

		<th>Kode Kuliah</th>
		<th>NIM</th>
		<th>Nilai</th>
		<th>Opsi</th>
	</tr>
	<tr>
		<?php
		$sql = mysql_query("select * from peserta") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?>
			<tr>
			<th><?php echo $data['kodekuliah']; ?></th>
			<th><?php echo $data['nim']; ?></th>
			<th><?php echo $data['nilai']; ?></th>
			<th><a href="?page=peserta&action=editpeserta&kode_kuliah=<?php echo $data['kodekuliah'];?>&nimmahasiswa=<?php echo $data['nim'];?>"><Button>Edit</Button></a>
			<a onclick="return confirm('Apakah anda akan menghapus data ini ?')" href=?page=peserta&action=hapuspeserta&kode_kuliah=<?php echo $data['kodekuliah'];?>&nimmahasiswa=<?php echo $data['nim'];?>><Button>Hapus</Button></a>
			</th>
			</tr>
	</tr>
	<?php
}
	?>
</table>