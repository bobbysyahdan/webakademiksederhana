<fieldset>
	<legend>Tambah Data Kuliah</legend>

<form method="post" action="">
<table>
	<tr>
		<td>Kode Kuliah</td>
		<td>:</td>
		<td><input type="text" name="kodekuliah"></td>
	</tr>
	<tr>
		<td>Kodemk</td>
		<td>:</td>
		<td><select name="kodemk">
		<?php
		$kode_mk = @$_GET['kode_mk'];
		$sql = mysql_query("select * from matakuliah") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>

		</select></td>
	</tr>
	<tr>
		<td>Nip</td>
		<td>:</td>
		<td><select name="nip">
		
		<?php
		$nipdosen = @$_GET['nipdosen'];
		$sql = mysql_query("select * from dosen") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
	?>
		</select></td>
	</tr>
	<tr>
		<td>Tahun Akademik</td>
		<td>:</td>
		<td><input type="text" name="thnakademik"></td>
	</tr>
	<tr>
		<td>Ruang</td>
		<td>:</td>
		<td><input type="text" name="ruang"></td>
	</tr>
	<tr>
		<td>Jam</td>
		<td>:</td>
		<td><input type="text" name="jam"></td>
	</tr>
	<tr>
		<td>Semester</td>
		<td>:</td>
		<td><input type="text" name="semester"></td>
	</tr>
	<tr>
		<td></td>
		<td></td>
		<td><input type="submit" name="tambah" value="Tambah"><input type="reset" name="reset" value="Batal"></td>
	</tr>
	</table>
	</form>
</fieldset>

<?php
$kodekuliah = @$_POST['kodekuliah'];
$kodemk = @$_POST['kodemk'];
$nip = @$_POST['nip'];
$thnakademik = @$_POST['thnakademik'];
$ruang = @$_POST['ruang'];
$jam = @$_POST['jam'];
$semester = @$_POST['semester'];
$tambah = @$_POST['tambah'];

if ($tambah) {
	if ($kodekuliah == "" || $kodemk == "" || $nip == "" || $thnakademik == "" || $ruang == "" || $jam == "" || $semester == "") {
		?>
		<script type="text/javascript">
			alert("Inputan masih ada yang kosong.")
		</script>
		<?php
	} else {
		mysql_query("insert into kuliah values('$kodekuliah','$kodemk','$nip','$thnakademik','$ruang','$jam','$semester')") or die (mysql_query());
	}
	?>
	<script type="text/javascript">
		alert("Data kuliah berhasil ditambah");
		window.location.href ="?page=kuliah";
	</script>
	<?php
}
?>


<br>
<br>
<h3 align="center">Data Kuliah</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>
		<th>Kode Kuliah</th>
		<th>Kodemk</th>
		<th>NIP</th>
		<th>Tahun Akademik</th>
		<th>Ruang</th>
		<th>Jam</th>
		<th>Semester</th>
		<th>Opsi</th>
	</tr>

		<?php
		$sql = mysql_query("select * from kuliah") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?>
			<tr>
				<th><?php echo $data['kodekuliah']; ?></th>
				<th><?php echo $data['kodemk']; ?></th>
				<th><?php echo $data['nip']; ?></th>
				<th><?php echo $data['thnakademik']; ?></th>
				<th><?php echo $data['ruang'];?></th>
				<th><?php echo $data['jam']; ?></th>
				<th><?php echo $data['semester']; ?></th>
				<th><a href="?page=kuliah&action=editkuliah&kode_kuliah=<?php echo $data['kodekuliah']; ?>"><button>Edit</button></a>
				<a onclick = "return confirm('Apakah anda yakin akan menghapus data ini ?')" href=?page=kuliah&action=hapuskuliah&kode_kuliah=<?php echo $data['kodekuliah']; ?>><button>Hapus</button></a></th>
				
			</tr>


		<?php
			}
		?>
	</tr>
</table>