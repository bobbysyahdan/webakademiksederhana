<?php
$nimmahasiswa = @$_GET['nimmahasiswa'];

mysql_query("delete from mahasiswa where nim='$nimmahasiswa'");
?>

<script type="text/javascript">
	window.location.href = "?page=mahasiswa";
</script>
