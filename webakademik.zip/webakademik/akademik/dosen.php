<fieldset>
	<legend>Menambah Data Dosen</legend>

<table>
<form method="post" action="">
	<tr>
		<td>NIP</td>
		<td>:</td>
		<td><input type="text" name="nip"></td>
	</tr>
	<tr>
	<td>Nama</td>
		<td>:</td>
		<td><input type="type" name="nama"></td>
	</tr>

	<tr>
		<td></td>
		<td></td>
		<td><input type="submit" name="tambah" value="Tambah"><input type="reset" name="reset" value="Batal"></td>
	</tr>
</form>
</table>

<?php
	$nip = @$_POST['nip'];
	$nama = @$_POST['nama'];
	$tambah = @$_POST['tambah'];


	if ($tambah) {
		if($nip == "" || $nama == "") {
		?>
		<script type=text/javascript>
			alert("Masih ada yang kosong");
		</script>

		<?php
	} else {
		mysql_query("insert into dosen values('$nip','$nama')") or die (mysql_error());
	}
	
	?>
	<script type="text/javascript">
	alert("Data dosen berhasil ditambah");
	window.location.href="?page=dosen" ;
	</script>
	<?php
	}

?>
</fieldset>

<br>
<br>
<h3 align="center">Data Dosen</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>
		<th>NIP</th>
		<th>Nama</th>
		<th>Opsi</th>
	</tr>

	<tr>
		<?php
		$sql = mysql_query("select * from dosen") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?>
			<tr>
				<th><?php echo $data['nip']; ?></th>
				<th><?php echo $data['nama']; ?></th>
				<th><a href="?page=dosen&action=editdosen&nipdosen=<?php echo $data['nip']; ?>"><button>Edit</button></a>
				<a onclick = "return confirm('Apakah anda yakin akan menghapus data ini ?')" href=?page=dosen&action=hapusdosen&nipdosen=<?php echo $data['nip']; ?>><button>Hapus</button></a></th>
				</tr>
		<?php
			}
		?>
	</tr>
</table>
