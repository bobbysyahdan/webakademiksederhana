<?php
$kode_kuliah = @$_GET['kode_kuliah'];
$nimmahasiswa = @$_GET['nimmahasiswa'];

mysql_query("delete from peserta where kodekuliah='$kode_kuliah' && nim='$nimmahasiswa'") or die(mysql_error());
?>

<script type="text/javascript">
	window.location.href = "?page=peserta";
</script>
