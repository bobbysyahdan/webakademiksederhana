<fieldset>
	<legend>Menambah Data Matakuliah</legend>

<form method="post" action="">

	<table>
		<tr>
			<td>Kode Matakuliah</td>
			<td>:</td>
			<td><input type="text" name="kodemk"></td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><input type="text" name="nama"></td>
		</tr>
		<tr>
			<td>SKS</td>
			<td>:</td>
			<td><input type="text" name="sks"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit" name="tambah" value="Tambah"><input type="reset" name="reset" value="Batal"></td>
		</tr>
	</table>
</form>
</fieldset>


<?php
	$kodemk = @$_POST['kodemk'];
	$nama = @$_POST['nama'];
	$sks = @$_POST['sks'];

	$tambah = @$_POST['tambah'];
	if ($tambah) {
		if ($kodemk == "" || $nama == "" || $sks == "") {
			?>
			<script type="text/javascript">
				alert("Inputan masih ada yang kosong");
			</script>
			<?php
		} else {
			mysql_query("insert into matakuliah values('$kodemk','$nama','$sks')") or die (mysql_error());
			?>
			<script type="text/javascript">
				alert("Data matakuliah berhasil ditambah.");
			</script>
			<?php
		} 
	}
?>

<br>
<h3 align="center">Data Matakuliah</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>
		<th width="20%">Kode Matakuliah</th>
		<th>Nama</th>
		<th>SKS</th>
		<th>Opsi</th>
	</tr>
		<?php
		$sql = mysql_query("select * from matakuliah") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?>
			<tr>
			<th><?php echo $data['kodemk']; ?></th>
			<th><?php echo $data['nama']; ?></th>
			<th><?php echo $data['sks']; ?></th>
			<th><a href="?page=matakuliah&action=editmatakuliah&kode_mk=<?php echo $data['kodemk']; ?> "><Button>Edit</Button></a>
			<a onclick="return confirm('Apakah anda akan menghapus data ini ?')" href=?page=matakuliah&action=hapusmatakuliah&kode_mk=<?php echo $data['kodemk']; ?>><Button>Hapus</Button></a>
			</th>
			</tr>
	</tr>
	<?php
}
	?>
</table>