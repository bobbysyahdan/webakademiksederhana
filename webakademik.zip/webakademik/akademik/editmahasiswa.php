<fieldset>
	<legend>Edit Data Mahasiswa</legend>

	<?php
	$nimmahasiswa = $_GET['nimmahasiswa'];
	$sql = mysql_query("select * from mahasiswa where nim ='$nimmahasiswa'") or die (mysql_error());
	$data = mysql_fetch_array($sql);

	?>
<table>
<form method="post" action="">
<tr>
	<td>NIM</td>
	<td>:</td>
	<td><input type="text" name="nim" value="<?php echo $data['nim']; ?>" disabled="disable"></td>
</tr>

<tr>
	<td>Nama</td>
	<td>:</td>
	<td><input type="text" name="nama" value="<?php echo $data['nama']; ?>"></td>
</tr>

<tr>
	<td>Dosen Pembimbing</td>
	<td>:</td>
	<td><select name="nip">
		<?php
		$nipdosen = @$_GET['nipdosen'];
		$sql = mysql_query("select * from dosen") or die (mysql_error());
		
		while ($data = mysql_fetch_array($sql)) {
			echo "<option value='$data[0]'>$data[1]</option>";
		}
		?>	
<tr>
	<td></td>
	<td></td>
	<td><input type="submit" name="update" value="update"><input type="reset" name="reset" value="Batal"></td>
</tr>
	</select></td>
</tr>
</form>
</table>
</fieldset>
<?php

	$nim = @$_POST['nim'];
	$nama = @$_POST['nama'];
	$nip = @$_POST['nip'];
	$update = @$_POST['update'];


	if ($update) {
		if($nama == "") {
		?>
		<script type=text/javascript>
			alert("Inputan masih ada yang kosong");
		</script>

		<?php
	} else {
		mysql_query("update mahasiswa set nama='$nama', dosenpembimbing='$nip' where nim = '$nimmahasiswa'") or die (mysql_error());
	}
	
	?>
	<script type="text/javascript">
	alert("Data mahasiswa berhasil diupdate");
	window.location.href="?page=mahasiswa" ;
	</script>
	<?php
	}
?>


