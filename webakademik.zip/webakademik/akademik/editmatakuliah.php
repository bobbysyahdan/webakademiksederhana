<fieldset>
	<legend>Update Data Matakuliah</legend>

	<?php
	$kode_mk = @$_GET['kode_mk'];
	$sql = mysql_query("select * from matakuliah where kodemk = '$kode_mk'") or die(mysql_error());
	$data = mysql_fetch_array($sql);
	?>

<form method="post" action="">

	<table>
		<tr>
			<td>Kode Matakuliah</td>
			<td>:</td>
			<td><input type="text" name="kodemk" value="<?php echo $data['kodemk']; ?>" disabled="disable"></td>
		</tr>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><input type="text" name="nama" value="<?php echo $data['nama']; ?>"></td>
		</tr>
		<tr>
			<td>SKS</td>
			<td>:</td>
			<td><input type="text" name="sks" value="<?php echo $data['sks']; ?>"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit" name="update" value="update"><input type="reset" name="reset" value="Batal"></td>
		</tr>
	</table>
</form>

<?php
$kodemk = @$_POST['kodemk'];
$nama = @$_POST['nama'];
$sks = @$_POST['sks'];
$update = @$_POST['update'];

if ($update) {
	if ($nama == "" || $sks == "") {
		?>
		<script type="text/javascript">
			alert("Inputan ada yang kosong.");
		</script>
		<?php
	} else {
		mysql_query("update matakuliah set nama ='$nama', sks = '$sks' where kodemk='$kode_mk'");
		?>
		<script type="text/javascript">
			alert("Data berhasil diupdate.");
			window.location.href="?page=matakuliah";
		</script>
		<?php
	}
}
?>
</fieldset>
