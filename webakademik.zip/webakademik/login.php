<?php
session_start();
include "inc/koneksi.php";

if (@$_SESSION['admin'] || @$_SESSION['member']) {
	header("loaction:index.php");
} else {

?>


<!DOCTYPE html>
<html>
<head>
	<title>Halaman Login</title>
	<link rel="stylesheet" href="css/style.css"/>
</head>
<body background="img/bg.jpg">

	<div id="utama">
		<div id="judul">
			Halaman Login
		</div>
		<div id="input">
			<form method="post" action="">
				<div>
					<input type="text" name="username" placeholder="username" class="input">
				</div>
				<div style="margin-top:10px;">
					<input type="password" name="password" placeholder="password" class="input">
				</div>
				<div style="margin-top:10px;">
					<input type="submit" name="login" value="Login" class="btn">
					<input type="submit" name="register" value="Register" class="btnreg">
				</div>
			</form>


			<?php
				$username = @$_POST['username'];
				$password = @$_POST['password'];
				$login = @$_POST['login'];
				$register = @$_POST['register'];

				if($login){
					if($username == "" || $password ==""){
						?>
						<script type="text/javascript">
							alert("Username atau password belum diisi.");
						</script>
						<?php
					} else {
						$sql = mysql_query("select * from user where username='$username' and password= md5('$password')") or die (mysql_error());
						$data = mysql_fetch_array($sql);
						$cek = mysql_num_rows($sql);

						if ($cek) {
							if($data['level'] == "admin") {
								@$_SESSION['admin'] = $data['username'];
								header("location:index.php");
							} elseif($data['level'] == "member") {
								@$_SESSION['member'] = $data['username'];
								header("location:index.php");
							}
						} else {
							?>
							<script type="text/javascript">
								alert("Username atau password anda salah. Silahkan login lagi !");
							</script>;
							<?php
						}
					}
				}

				if ($register) {
					header("location:register.php");
				}
			?>
		</div>
	</div>
</body>
</html>

<?php
}
?>