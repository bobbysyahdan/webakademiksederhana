<!DOCTYPE html>
<html>
<head>
	<title>Profil</title>
</head>
<body>
<br><center><img src="img/foto.jpg" height=250 width=200></br>
<h1><b><center>PROFIL SAYA</b></h1>
<table p align=center>
<tr>
<td><b>NAMA</td>
<td><b>: MUHAMMAD BOBBY SYAHDAN LUBIS</td>
</tr>
<tr>
<td><b>KELAS</td>
<td><b>: 3TKJ1</td>
</tr>
<tr>
<td><b>ALAMAT</td>
<td><b>: JL. PUKAT 4 NO.47 MEDAN</td>
</tr>
<tr>
<td><b>EMAIL</td>
<td><b>: muhammadbobby952@yahoo.co.id</td>
</tr></b></table>
</body>
</html>