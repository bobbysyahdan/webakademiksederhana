<?php
@session_start();
include "inc/koneksi.php";
?>

<!DOCTYPE html>
<html>
<head>
	<title>Buku Tamu</title>
</head>
<body>
<form method="post" action="">
	<table align="center">
	<h2 align="center">Buku Tamu</h2>

	<?php
				if(@$_SESSION['admin']) {
					$user_terlogin = $_SESSION['admin'];
				} else if(@$_SESSION['member']) {
					$user_terlogin = $_SESSION['member'];
				}

			$sql_user = mysql_query("select * from user where username= '$user_terlogin'") or die (mysql_error());
			$data = mysql_fetch_array($sql_user);
			?>
		<tr>
			<td>Username</td>
			<td>:</td>
			<td><input type="text" name="username" value="<?php echo $data[0];?>"></td>
		</tr>
		<tr>
			<td>Email</td>
			<td>:</td>
			<td><input type="text" name="email" value="<?php echo $data['email'];?>"></td>
		</tr>
		<tr>
			<td>Komentar</td>
			<td>:</td>
			<td><input type="text" name="komen"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td><input type="submit" name="komentar" value="Komentar"><input type="reset" name="reset" value="Batal"></td>
		</tr>
	</table>
</form>

<?php

if (@$_POST['komentar']) {
$username = @$_POST['username'];
$email = @$_POST['email'];
$komen = @$_POST['komen'];


if ($username == "" || $email == "" || $komen == "") {
		?>
		<script type="text/javascript">
			alert("Komentar harus diisi");
		</script>
		<?php
	} else {
		mysql_query("insert into bukutamu values('$username','$email','$komen')") or die (mysql_error());
		?>
		<script type="text/javascript">
			alert("Terima kasih sudah berpatisipasi.");
			window.location.href="?page=bukutamu";
		</script>
		<?php
	}
}
?>
<br>
<h3 align="center">Buku Tamu</h3>
<table width="100%" border="1px" style="border-collapse:collapse;">
	<tr style="background-color:#fc0";>
		<th>Username</th>
		<th>Email</th>
		<th>Komentar</th>
	</tr>
	<tr>
		<?php
		$sql = mysql_query("select * from bukutamu") or die (mysql_error());
		while ($data = mysql_fetch_array($sql)) {
			?> 

			<th><?php echo $data['username']; ?></th>
			<th><?php echo $data['email']; ?></th>
			<th><?php echo $data['komen']; ?></th>
	</tr>
	<?php
}
	?>
	</table>
</body>
</html>