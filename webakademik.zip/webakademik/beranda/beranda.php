<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br><h2>POLITEKNIK NEGERI MEDAN</h2>

<br><img src="img/z.jpg" />
<br>
<br>Sebagai salah satu perguruan tinggi negeri di Sumatera Utara, Politeknik Negeri Medan saat ini menjadi pusat pendidikan vokasi yang berfokus pada pengembangan kemampuan sumber daya manusia dan memiliki visi global untuk turut serta meningkatkan angka partisipasi kasar pendidikan di Indonesia.

<br>	Dengan 16 program studi yang ada dan fasilitas kampus seluas 8.5 ha, Politeknik Negeri Medan mempersiapkan kurikulum berbasis kompetensi yang sesuai dengan kebutuhan industri. Politeknik Negeri Medan juga memberikan beasiswa bagi mahasiswa tidak mampu dan turut serta mengembangkan jiwa wirausaha bagi para peserta didik. Saat ini Politeknik Negeri Medan mendidik lebih dari 5.500 mahasiswa dan telah menamatkan lebih dari 20.000 alumni yang telah bekerja di berbagai sektor industri.

<br>	Politeknik Negeri Medan secara aktif juga terlibat dalam berbagai penelitian terapan. Selain itu para dosen Politeknik Negeri Medan juga ikut serta dalam berbagai kegiatan pengabdian masyarakat sebagai rasa tanggung jawab sosial. Selain itu dalam rangka pengembangan jaringan, Politeknik Negeri Medan juga melakukan berbagai kerjasama dengan berbagai pihak baik regional maupun internasional
 
</body>
</html>