<?php
session_start();
include "inc/koneksi.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Halaman Register</title>
	<link rel="stylesheet" href="css/style.css"/>
</head>
<body background="img/bg.jpg">

	<div id="register">
		<div id="judul">
			Halaman Register
		</div>
		<div id="input">
			<form method="post" action="">
				<div>
					<input type="text" name="username" placeholder="username" class="input">
				</div>

				<div style="margin-top:10px;">
					<input type="text" name="nama_lengkap" placeholder="Nama Lengkap" class="input">
				</div>

				<div style="margin-top:10px;">
					<input type="password" name="password" placeholder="Password" class="input">
				</div>

				<div style="margin-top:10px;">
					<input type="email" name="email" placeholder="Email" class="input">
				</div>

				<div style="margin-top:10px;">
					<select name="jenis_kelamin">
						<option value="">- Pilih Jenis Kelamin -</option>
						<option value="Laki-laki">Laki-Laki</option>
						<option value="Perempuan">Perempuan</option>
					</select>
				</div>

				<div style="margin-top:10px;">
					<input type="submit" name="register" value="Register" class="btn">
					<input type="submit" name="login" value="Login" class="btnreg">
				</div>
		</form>
		</div>
		</div>

	<?php
	$login = @$_POST['login'];

	$register = @$_POST['register'];
		
		$username = @$_POST['username'];
		$nama_lengkap = @$_POST['nama_lengkap'];
		$password = @$_POST['password'];
		$email = @$_POST['email'];
		$jenis_kelamin = @$_POST['jenis_kelamin'];
		
		if ($register) {
		if ($username == "" || $nama_lengkap == "" || $password == "" || $jenis_kelamin == "") {
			?>
			<script type="text/javascript">
				alert("Inputan tidak boleh ada yang kosong.");
			</script>
			<?php
		} else {
			mysql_query("insert into user values('$username','$nama_lengkap',md5('$password'),'$email','$jenis_kelamin','member')") or die (mysql_error());
		 ?> 
				<script type="text/javascript">
					alert("Akun anda sudah berhasil terdaftar, Silahkan Login !");
					window.location.href= "login.php";
				</script>
				<?php
			}
		}
	
	if($login) {
		header("location:login.php");
	}
	?>
</body>
</html>
